package acadevs.entreculturas.dao.xml;

public class XMLAdministracionFisicaDAO {

}
