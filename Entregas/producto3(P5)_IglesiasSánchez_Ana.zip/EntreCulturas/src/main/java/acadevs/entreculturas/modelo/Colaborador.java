package acadevs.entreculturas.modelo;

public class Colaborador extends Persona {

	public Colaborador () {
		super();
	}

	public Colaborador(String dni, String nombre, String apellidos, String telefono, String domicilio,
			String fechaInicio, String fechaFin, AdministracionFisica sedeAsignada, String cargo, String correo) {
		super();
	}
}
