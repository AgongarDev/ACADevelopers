package acadevs.entreculturas.dao;

import acadevs.entreculturas.modelo.AdministracionFisica;

public interface IAdministracionFisicaDAO extends IDAO<AdministracionFisica, String> {
	
}
